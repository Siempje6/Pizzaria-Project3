﻿using System.Windows.Controls;
using $safeprojectname$.ViewModel;

namespace $safeprojectname$.View
{
    public partial class ContactInfoView : UserControl
    {
        public ContactInfoView()
        {
            InitializeComponent();
            this.DataContext = new ContactInfoViewModel();
        }
    }
}
